======
PyAFBF
======

This package is intended for the simulation of image textures from a mathematical model called the anisotropic fractional Brownian fields.

Installation from sources
=========================

In the root directory of the package, just do::

    python setup.py install
    or
    pip install -e .
