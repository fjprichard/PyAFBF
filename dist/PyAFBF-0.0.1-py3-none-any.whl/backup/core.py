#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from datetime import datetime


def proclamer():
    print("[%s] F. Richard, AMU, 2021.", datetime.now())


if __name__ == "__main__":
    proclamer()
