Credits
=======

PyAFBF is written and maintained by Frederic Richard, Professor at Aix-Marseille University, France.


Contributors
------------

Frederic Richard